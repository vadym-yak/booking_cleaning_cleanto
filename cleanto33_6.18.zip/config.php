<?php
	class cleanto_myvariable{
	public $hostnames = 'localhost';
	public $username = 'root';
	public $passwords = '';
	public $database = 'cleanto';
	public $epcode = '234234';
} ?>