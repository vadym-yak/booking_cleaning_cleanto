<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing SendCustomerTransactionReceiptResponse
 */
class SendCustomerTransactionReceiptResponse extends ANetApiResponseType
{


}

